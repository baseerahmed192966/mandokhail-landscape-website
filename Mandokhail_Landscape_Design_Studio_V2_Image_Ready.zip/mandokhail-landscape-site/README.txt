MANDOKHAIL LANDSCAPE DESIGN STUDIO

Static luxury landscape studio website.

FILES
- index.html: website structure/content
- style.css: styling/responsive layout
- script.js: mobile navigation/interactions
- assets/: logo and all local image slots
- IMAGE_GUIDE.txt: exact photo checklist and replacement instructions

IMAGE WORKFLOW
1. Replace the SVG image slots in assets/ with your real photographs.
2. Keep the filenames exactly the same, or update the matching path in index.html/style.css.
3. Commit changes to GitHub.
4. Cloudflare Pages will deploy the commit automatically if auto-deploy is enabled.

IMPORTANT
The supplied ZIP did not contain the real project photographs, so local SVG placeholders are included to keep the website functional and make every required image slot obvious. Replace them with your own photos before publishing.
